﻿using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;

public class ChunkHandler : MonoBehaviour
{
    [SerializeField] GameObject player;
    [SerializeField] GameObject chunkParent; 
    [SerializeField] GameObject chunkPrefab;
    [SerializeField] float checkInterval;
    [SerializeField] List<GameObjectPrefab> objectsToPool;

    private List<GameObject> chunkMap = new();

    void Start()
    {
        GameObject firstGeneratedChunk = Instantiate(chunkPrefab, Vector3.zero, Quaternion.identity, chunkParent.transform);
        chunkMap.Add(firstGeneratedChunk);
        SpawnEnvironmentObjectsOnChunk(firstGeneratedChunk);
        StartCoroutine(CheckPlayerPosition());
    }

    IEnumerator CheckPlayerPosition()
    {
        float border = 10f;

        while (true)
        {
            foreach (GameObject c in new List<GameObject>(chunkMap))
            {

                if (player.transform.position.x >= c.GetComponent<Terrain>().GetPosition().x && player.transform.position.x <= c.GetComponent<Terrain>().GetPosition().x + border && player.transform.position.z >= c.GetComponent<Terrain>().GetPosition().z && player.transform.position.z <= c.GetComponent<Terrain>().GetPosition().z + c.GetComponent<Terrain>().terrainData.size.z)
                {
                    // Creazione del chunk a sinistra di quello dove si trova il player
                    if (!c.GetComponent<ChunkDetails>().GetLeftChunkWasGenerated())
                    {
                        Vector3 spawnPosition = new Vector3(c.transform.position.x - c.GetComponent<Terrain>().terrainData.size.x, 0f, c.transform.position.z); // Y = altezza, qui messa a 0

                        GameObject newChunk = Instantiate(chunkPrefab, spawnPosition, Quaternion.identity, chunkParent.transform);

                        chunkMap.Add(newChunk);

                        FindAdjacentChunks(newChunk);
                        SpawnEnvironmentObjectsOnChunk(newChunk);
                    }
                }
                if (player.transform.position.x >= c.GetComponent<Terrain>().GetPosition().x + c.GetComponent<Terrain>().terrainData.size.x - border && player.transform.position.x <= c.GetComponent<Terrain>().GetPosition().x + c.GetComponent<Terrain>().terrainData.size.x && player.transform.position.z >= c.GetComponent<Terrain>().GetPosition().z && player.transform.position.z <= c.GetComponent<Terrain>().GetPosition().z + c.GetComponent<Terrain>().terrainData.size.z)
                {
                    // creazione del chunk a destra di quello dove si trova il player
                    if (!c.GetComponent<ChunkDetails>().GetRightChunkWasGenerated())
                    {
                        Vector3 spawnPosition = new Vector3(c.transform.position.x + c.GetComponent<Terrain>().terrainData.size.x, 0f, c.transform.position.z); // Y = altezza, qui messa a 0

                        GameObject newChunk = Instantiate(chunkPrefab, spawnPosition, Quaternion.identity, chunkParent.transform);

                        chunkMap.Add(newChunk);                       

                        FindAdjacentChunks(newChunk);
                        SpawnEnvironmentObjectsOnChunk(newChunk);
                    }
                }
                if (player.transform.position.z >= c.GetComponent<Terrain>().GetPosition().z && player.transform.position.z <= c.GetComponent<Terrain>().GetPosition().z + border && player.transform.position.x >= c.GetComponent<Terrain>().GetPosition().x && player.transform.position.x <= c.GetComponent<Terrain>().GetPosition().x + c.GetComponent<Terrain>().terrainData.size.x)
                {
                    if (!c.GetComponent<ChunkDetails>().GetBottomChunkWasGenerated())
                    {
                        Vector3 spawnPosition = new Vector3(c.transform.position.x, 0f, c.transform.position.z - c.GetComponent<Terrain>().terrainData.size.z); // Y = altezza, qui messa a 0

                        GameObject newChunk = Instantiate(chunkPrefab, spawnPosition, Quaternion.identity, chunkParent.transform);

                        chunkMap.Add(newChunk);

                        FindAdjacentChunks(newChunk);
                        SpawnEnvironmentObjectsOnChunk(newChunk);
                    }
                }
                if (player.transform.position.z >= c.GetComponent<Terrain>().GetPosition().z + c.GetComponent<Terrain>().terrainData.size.z - border && player.transform.position.z <= c.GetComponent<Terrain>().GetPosition().z + c.GetComponent<Terrain>().terrainData.size.z && player.transform.position.x >= c.GetComponent<Terrain>().GetPosition().x && player.transform.position.x <= c.GetComponent<Terrain>().GetPosition().x + c.GetComponent<Terrain>().terrainData.size.x)
                {
                    if (!c.GetComponent<ChunkDetails>().GetTopChunkWasGenerated())
                    {
                        Vector3 spawnPosition = new Vector3(c.transform.position.x, 0f, c.transform.position.z + c.GetComponent<Terrain>().terrainData.size.z); // Y = altezza, qui messa a 0

                        GameObject newChunk = Instantiate(chunkPrefab, spawnPosition, Quaternion.identity, chunkParent.transform);

                        chunkMap.Add(newChunk);

                        FindAdjacentChunks(newChunk);
                        SpawnEnvironmentObjectsOnChunk(newChunk);
                    }
                }
            }
            UpdateChunkVisibility();
            yield return new WaitForSeconds(checkInterval);
        }
    }

    public GameObject FindActualChunk(GameObject player, GameObject chunk)
    {
        if (player.transform.position.x >= chunk.GetComponent<Terrain>().GetPosition().x && player.transform.position.x < chunk.GetComponent<Terrain>().GetPosition().x + chunk.GetComponent<Terrain>().terrainData.size.x && player.transform.position.z >= chunk.GetComponent<Terrain>().GetPosition().z && player.transform.position.z < chunk.GetComponent<Terrain>().GetPosition().z + chunk.GetComponent<Terrain>().terrainData.size.z)
        {
            return chunk;
        }
        return null;
    }

    public void FindAdjacentChunks(GameObject newChunk)
    {

        foreach (GameObject c in chunkMap)
        {

            // LEFT
            if (c.transform.position.z == newChunk.transform.position.z && c.transform.position.x == newChunk.transform.position.x - 50)
            {
                newChunk.GetComponent<ChunkDetails>().SetLeftChunkWasGenerated(true);
                c.GetComponent<ChunkDetails>().SetRightChunkWasGenerated(true);
            }

            // RIGHT
            if (c.transform.position.z == newChunk.transform.position.z && c.transform.position.x == newChunk.transform.position.x + 50)
            {
                newChunk.GetComponent<ChunkDetails>().SetRightChunkWasGenerated(true);
                c.GetComponent<ChunkDetails>().SetLeftChunkWasGenerated(true);
            }

            // BOTTOM
            if (c.transform.position.x == newChunk.transform.position.x && c.transform.position.z == newChunk.transform.position.z - 50)
            {
                newChunk.GetComponent<ChunkDetails>().SetBottomChunkWasGenerated(true); 
                c.GetComponent<ChunkDetails>().SetTopChunkWasGenerated(true);
            }

            // TOP
            if (c.transform.position.x == newChunk.transform.position.x && c.transform.position.z == newChunk.transform.position.z + 50)
            {
                newChunk.GetComponent<ChunkDetails>().SetTopChunkWasGenerated(true);
                c.GetComponent<ChunkDetails>().SetBottomChunkWasGenerated(true);
            }
        }
    }

    public void UpdateChunkVisibility()
    {
        GameObject actualChunk = null;

        foreach (GameObject c in chunkMap)
        {
            actualChunk = FindActualChunk(player, c);
            if (actualChunk != null)
            {
                break;
            }
        }

        List<Vector3> activePositions = new() { actualChunk.transform.position };

        if (actualChunk.GetComponent<ChunkDetails>().GetLeftChunkWasGenerated())
        {
            activePositions.Add(new Vector3(actualChunk.transform.position.x - 50, 0f, actualChunk.transform.position.z));
        }
        if (actualChunk.GetComponent<ChunkDetails>().GetRightChunkWasGenerated())
        {
            activePositions.Add(new Vector3(actualChunk.transform.position.x + 50, 0f, actualChunk.transform.position.z));
        }
        if (actualChunk.GetComponent<ChunkDetails>().GetBottomChunkWasGenerated())
        {
            activePositions.Add(new Vector3(actualChunk.transform.position.x, 0f, actualChunk.transform.position.z - 50));
        }
        if (actualChunk.GetComponent<ChunkDetails>().GetTopChunkWasGenerated())
        {
            activePositions.Add(new Vector3(actualChunk.transform.position.x, 0f, actualChunk.transform.position.z + 50));
        }

        foreach (GameObject chunk in chunkMap)
        {
            bool shouldBeActive = false;

            foreach (Vector3 activePos in activePositions)
            {
                if (chunk.transform.position.x == activePos.x && chunk.transform.position.z == activePos.z)
                {
                    shouldBeActive = true;
                    break;
                }
            }

            if (chunk.activeSelf != shouldBeActive)
                chunk.SetActive(shouldBeActive);
        }
    }

    Vector3 CalculateSpawnPosition(GameObject chunk)
    {
        float x = UnityEngine.Random.Range(chunk.GetComponent<Terrain>().GetPosition().x, chunk.GetComponent<Terrain>().GetPosition().x + chunk.GetComponent<Terrain>().terrainData.size.x);
        float z = UnityEngine.Random.Range(chunk.GetComponent<Terrain>().GetPosition().z, chunk.GetComponent<Terrain>().GetPosition().z + chunk.GetComponent<Terrain>().terrainData.size.z);
        float height = chunk.GetComponent<Terrain>().terrainData.size.y + 50;

        Vector3 rayOrigin = new(x, height, z);
        //Ray ray = new(rayOrigin, Vector3.down);

        Physics.Raycast(rayOrigin, Vector3.down, out RaycastHit hit, height);
        if (hit.collider is TerrainCollider) 
        { 
            return hit.point;
        }
        return new Vector3(0f, 0f, -9999f);
    }

    void SpawnEnvironmentObjectsOnChunk(GameObject chunk)
    {
        int amountToSpawn;
        foreach (GameObjectPrefab element in objectsToPool)
        {
            if (element.prefab.name.Contains("Flower")) {
                amountToSpawn = UnityEngine.Random.Range(50, 101);
            } 
            else if (element.prefab.name.Contains("Rock"))
            {
                amountToSpawn = UnityEngine.Random.Range(10, 16);
            }
            else if (element.prefab.name.Contains("Grass"))
            {
                amountToSpawn = UnityEngine.Random.Range(100, 201);
            } 
            else
            {
                amountToSpawn = UnityEngine.Random.Range(75, 131);
            }

            for (int i = 0; i < amountToSpawn; i++)
            {
                Vector3 spawnPos = CalculateSpawnPosition(chunk);
                if (spawnPos.y > -9998f)
                {
                    Vector3 randomEuler = new Vector3(
                        UnityEngine.Random.Range(element.minRotation.x, element.maxRotation.x),
                        UnityEngine.Random.Range(element.minRotation.y, element.maxRotation.y),
                        UnityEngine.Random.Range(element.minRotation.z, element.maxRotation.z)
                    );
                    GameObject obj = Instantiate(element.prefab, spawnPos, Quaternion.identity, chunk.transform);
                    Vector3 randomScale = new Vector3(
                        UnityEngine.Random.Range(element.minScale.x, element.maxScale.x),
                        UnityEngine.Random.Range(element.minScale.y, element.maxScale.y),
                        UnityEngine.Random.Range(element.minScale.z, element.maxScale.z)
                    );
                    obj.transform.localScale = randomScale;
                    obj.SetActive(true);
                }
            }
        }
    }
}