﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PlayerController : MonoBehaviour
{
    [SerializeField] float speed;

    private CharacterController controller;
    private Vector3 directionMovement;
    private Vector3 velocity;

    private float moveX;
    private float moveZ;

    void Start()
    {
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        moveX = Input.GetAxis("Horizontal");
        moveZ = Input.GetAxis("Vertical");

        directionMovement = transform.right * moveX + transform.forward * moveZ;

        if (directionMovement.magnitude > 1f)
        {
            directionMovement.Normalize();
        }

        velocity.x = directionMovement.x * speed;
        velocity.z = directionMovement.z * speed;

        if (controller.isGrounded)
        {
            velocity.y = 0f;
        }
        else
        {
            velocity.y += Physics.gravity.y * Time.deltaTime;
        }

        controller.Move(velocity * Time.deltaTime);
    }
}