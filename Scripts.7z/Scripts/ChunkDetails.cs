using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ChunkDetails : MonoBehaviour
{
    private bool leftChunkWasGenerated;
    private bool rightChunkWasGenerated;
    private bool bottomChunkWasGenerated;
    private bool topChunkWasGenerated;

    public bool GetLeftChunkWasGenerated()
    {
        return leftChunkWasGenerated; 
    }

    public void SetLeftChunkWasGenerated(bool leftChunkWasGenerated)
    {
        this.leftChunkWasGenerated = leftChunkWasGenerated;
    }

    public bool GetRightChunkWasGenerated()
    {
        return rightChunkWasGenerated;
    }

    public void SetRightChunkWasGenerated(bool rightChunkWasGenerated)
    {
        this.rightChunkWasGenerated = rightChunkWasGenerated;
    }

    public bool GetBottomChunkWasGenerated()
    {
        return bottomChunkWasGenerated;
    }

    public void SetBottomChunkWasGenerated(bool bottomChunkWasGenerated)
    {
        this.bottomChunkWasGenerated = bottomChunkWasGenerated;
    }

    public bool GetTopChunkWasGenerated()
    {
        return topChunkWasGenerated;
    }

    public void SetTopChunkWasGenerated(bool topChunkWasGenerated)
    {
        this.topChunkWasGenerated = topChunkWasGenerated;
    }
}