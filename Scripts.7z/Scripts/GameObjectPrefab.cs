using UnityEngine;

[System.Serializable]
public class GameObjectPrefab : MonoBehaviour
{
    public GameObject prefab;

    [Header("Random Scale Range")]
    public Vector3 minScale = Vector3.one;
    public Vector3 maxScale = Vector3.one;

    [Header("Random Rotation Range")]
    public Vector3 minRotation = Vector3.zero;
    public Vector3 maxRotation = Vector3.zero;
}
